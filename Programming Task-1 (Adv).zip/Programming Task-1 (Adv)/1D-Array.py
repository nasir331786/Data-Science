class Solution:
    def runningSum(self, nums):
        running = 0
        ans = []
        for n in nums:
            running += n
            ans.append(running)
        return ans
